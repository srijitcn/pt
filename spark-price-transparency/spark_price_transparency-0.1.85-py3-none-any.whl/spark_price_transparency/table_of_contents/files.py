from ..pt_files import Pt_files

class Table_of_contents(Pt_files):

    _meta_ingest_tbl = "pt_stage.toc_header"
