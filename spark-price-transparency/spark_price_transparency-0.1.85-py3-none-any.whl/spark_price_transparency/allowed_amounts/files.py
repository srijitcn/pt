from ..pt_files import Pt_files

class Allowed_amounts(Pt_files):

    _meta_ingest_tbl = "pt_stage.aa_header"
